import React, { useState } from 'react';
import { Mail, Phone, MessageCircle, Send, MapPin } from 'lucide-react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    project: '',
    budget: '',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simular envio do formulário
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Reset form
    setFormData({
      name: '',
      email: '',
      project: '',
      budget: '',
      message: ''
    });
    
    setIsSubmitting(false);
    alert('Mensagem enviada com sucesso! Retornarei em breve.');
  };

  const projectTypes = [
    'Landing Page Nova',
    'Otimização de Conversão',
    'Copy para Landing Page',
    'Integração com Ferramentas',
    'Consultoria em CRO',
    'Projeto Completo'
  ];

  const budgetRanges = [
    'R$ 1.000 - R$ 3.000',
    'R$ 3.000 - R$ 5.000',
    'R$ 5.000 - R$ 10.000',
    'R$ 10.000 - R$ 20.000',
    'Acima de R$ 20.000',
    'Vamos conversar sobre o orçamento'
  ];

  const whatsappMessage = encodeURIComponent('Olá! Quero fazer um site de alta conversão. Podemos conversar sobre meu projeto?');

  return (
    <section id="contact" className="py-20 lg:py-32 bg-white dark:bg-dark-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              Vamos Conversar?
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Pronto para transformar sua ideia em uma landing page que converte? 
              Entre em contato e vamos discutir como posso ajudar seus resultados.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-16">
            {/* Contact Form */}
            <div className="bg-gray-50 dark:bg-dark-800/50 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                Solicite seu Orçamento
              </h3>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Nome Completo *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-dark-600 bg-white dark:bg-dark-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-cobalt-500 focus:border-transparent transition-all duration-200"
                      placeholder="Seu nome"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      E-mail *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-dark-600 bg-white dark:bg-dark-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-cobalt-500 focus:border-transparent transition-all duration-200"
                      placeholder="seu@email.com"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="project" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Tipo de Projeto *
                    </label>
                    <select
                      id="project"
                      name="project"
                      required
                      value={formData.project}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-dark-600 bg-white dark:bg-dark-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-cobalt-500 focus:border-transparent transition-all duration-200"
                    >
                      <option value="">Selecione o tipo</option>
                      {projectTypes.map((type, index) => (
                        <option key={index} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label htmlFor="budget" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Orçamento Aproximado
                    </label>
                    <select
                      id="budget"
                      name="budget"
                      value={formData.budget}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-dark-600 bg-white dark:bg-dark-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-cobalt-500 focus:border-transparent transition-all duration-200"
                    >
                      <option value="">Selecione a faixa</option>
                      {budgetRanges.map((range, index) => (
                        <option key={index} value={range}>{range}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Descreva seu Projeto *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    required
                    rows={5}
                    value={formData.message}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-dark-600 bg-white dark:bg-dark-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-cobalt-500 focus:border-transparent transition-all duration-200 resize-none"
                    placeholder="Conte-me mais sobre seu projeto, objetivo, público-alvo e qualquer detalhe que julgar importante..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`w-full flex items-center justify-center px-8 py-4 bg-cobalt-600 hover:bg-cobalt-700 disabled:bg-cobalt-400 text-white font-semibold rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1 disabled:transform-none ${
                    isSubmitting ? 'cursor-not-allowed' : ''
                  }`}
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                      Enviando...
                    </>
                  ) : (
                    <>
                      Enviar Mensagem
                      <Send className="ml-2 w-5 h-5" />
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* Contact Info */}
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                  Outras Formas de Contato
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-8 leading-relaxed">
                  Prefere um contato mais direto? Fique à vontade para me chamar no WhatsApp 
                  ou enviar um e-mail. Respondo a todas as mensagens em até 24 horas.
                </p>
              </div>

              {/* Contact Methods */}
              <div className="space-y-6">
                <a
                  href={`https://wa.me/5561996749932?text=${whatsappMessage}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center p-6 bg-green-50 dark:bg-green-900/20 rounded-2xl hover:bg-green-100 dark:hover:bg-green-900/30 transition-all duration-300 group"
                >
                  <div className="bg-green-500 p-3 rounded-xl mr-4 group-hover:scale-110 transition-transform duration-300">
                    <MessageCircle className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white">WhatsApp</h4>
                    <p className="text-green-600 dark:text-green-400">(61) 9 9674-9932</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Resposta mais rápida</p>
                  </div>
                </a>

                <a
                  href="mailto:guiwebdesigner2025@gmail.com"
                  className="flex items-center p-6 bg-blue-50 dark:bg-blue-900/20 rounded-2xl hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-all duration-300 group"
                >
                  <div className="bg-blue-500 p-3 rounded-xl mr-4 group-hover:scale-110 transition-transform duration-300">
                    <Mail className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white">E-mail</h4>
                    <p className="text-blue-600 dark:text-blue-400">guiwebdesigner2025@gmail.com</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Para propostas detalhadas</p>
                  </div>
                </a>

                <div className="flex items-center p-6 bg-gray-50 dark:bg-dark-800 rounded-2xl">
                  <div className="bg-gray-500 p-3 rounded-xl mr-4">
                    <MapPin className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white">Localização</h4>
                    <p className="text-gray-600 dark:text-gray-400">Luziânia, GO - Brasil</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Atendimento remoto</p>
                  </div>
                </div>
              </div>

              {/* FAQ */}
              <div className="bg-cobalt-50 dark:bg-cobalt-900/20 rounded-2xl p-6">
                <h4 className="font-semibold text-gray-900 dark:text-white mb-4">
                  Perguntas Frequentes
                </h4>
                <div className="space-y-3 text-sm">
                  <div>
                    <p className="font-medium text-gray-700 dark:text-gray-300">Quanto tempo leva um projeto?</p>
                    <p className="text-gray-600 dark:text-gray-400">Entre 7-15 dias úteis, dependendo da complexidade.</p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-700 dark:text-gray-300">Fazem revisões?</p>
                    <p className="text-gray-600 dark:text-gray-400">Sim! Até 3 rodadas de revisão estão incluídas.</p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-700 dark:text-gray-300">Oferecem suporte pós-entrega?</p>
                    <p className="text-gray-600 dark:text-gray-400">30 dias de suporte gratuito para ajustes.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
import React from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Portfolio from './components/Portfolio';
import Services from './components/Services';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import { MessageCircle } from 'lucide-react';

function App() {
  const whatsappMessage = encodeURIComponent('Olá! Quero fazer um site de alta conversão. Podemos conversar sobre meu projeto?');

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-white dark:bg-dark-900 transition-colors duration-300">
        <Header />
        <main>
          <Hero />
          <About />
          <Portfolio />
          <Services />
          <Testimonials />
          <Contact />
        </main>
        
        {/* Fixed CTA Button */}
        <a
          href={`https://wa.me/5561996749932?text=${whatsappMessage}`}
          target="_blank"
          rel="noopener noreferrer"
          className="fixed right-6 bottom-6 z-40 group"
          aria-label="Solicitar Orçamento"
        >
          <div className="bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-2xl hover:shadow-green-500/25 transition-all duration-300 transform hover:scale-110 hover:-translate-y-1">
            <MessageCircle className="w-6 h-6" />
          </div>
          <div className="absolute right-16 top-1/2 transform -translate-y-1/2 bg-gray-900 dark:bg-white text-white dark:text-gray-900 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
            Quero um site de alta conversão
          </div>
        </a>

        {/* Footer */}
        <footer className="bg-gray-900 dark:bg-black text-white py-12">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-6xl mx-auto">
              <div className="grid md:grid-cols-3 gap-8">
                <div>
                  <h3 className="text-2xl font-bold bg-gradient-to-r from-cobalt-400 to-blue-400 bg-clip-text text-transparent mb-4">
                    Guilherme
                  </h3>
                  <p className="text-gray-400 leading-relaxed">
                    Transformo ideias em páginas que vendem.
                  </p>
                </div>
                
                <div>
                  <h4 className="font-semibold text-white mb-4">Links Rápidos</h4>
                  <ul className="space-y-2">
                    <li><a href="#about" className="text-gray-400 hover:text-cobalt-400 transition-colors">Sobre</a></li>
                    <li><a href="#portfolio" className="text-gray-400 hover:text-cobalt-400 transition-colors">Portfólio</a></li>
                    <li><a href="#services" className="text-gray-400 hover:text-cobalt-400 transition-colors">Serviços</a></li>
                    <li><a href="#contact" className="text-gray-400 hover:text-cobalt-400 transition-colors">Contato</a></li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold text-white mb-4">Contato</h4>
                  <div className="space-y-2 text-gray-400">
                    <p>Luziânia, GO - Brasil</p>
                    <p>guiwebdesigner2025@gmail.com</p>
                    <p>(61) 9 9674-9932</p>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
                <p>&copy; 2025 Guilherme. Todos os direitos reservados.</p>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </ThemeProvider>
  );
}

export default App;
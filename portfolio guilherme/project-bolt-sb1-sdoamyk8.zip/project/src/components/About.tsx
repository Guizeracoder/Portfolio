import React from 'react';
import { Target, Zap, TrendingUp, Award, Code, Palette } from 'lucide-react';

const About: React.FC = () => {
  const skills = [
    {
      icon: <Target className="w-8 h-8" />,
      title: 'Foco em Conversão',
      description: 'Cada elemento é pensado estrategicamente para maximizar as taxas de conversão e gerar mais leads qualificados.'
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: 'Performance Otimizada',
      description: 'Landing pages ultra-rápidas com carregamento otimizado, garantindo a melhor experiência do usuário.'
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: 'Resultados Mensuráveis',
      description: 'Implementação de analytics avançados para acompanhar métricas e otimizar continuamente os resultados.'
    },
    {
      icon: <Award className="w-8 h-8" />,
      title: 'Design Profissional',
      description: 'Interfaces modernas e elegantes que transmitem credibilidade e confiança para sua marca.'
    },
    {
      icon: <Code className="w-8 h-8" />,
      title: 'Código Limpo',
      description: 'Desenvolvimento com as melhores práticas, garantindo manutenibilidade e escalabilidade do projeto.'
    },
    {
      icon: <Palette className="w-8 h-8" />,
      title: 'UX/UI Strategy',
      description: 'Design centrado no usuário com foco na jornada de compra e redução de atritos no processo de conversão.'
    }
  ];

  return (
    <section id="about" className="py-20 lg:py-32 bg-white dark:bg-dark-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              Sobre Mim
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Desenvolvedor especializado em criar landing pages que não apenas impressionam visualmente, 
              mas que são estrategicamente construídas para converter visitantes em clientes.
            </p>
          </div>

          <div className="mb-20">
            {/* Content */}
            <div className="space-y-6">
              <h3 className="text-2xl lg:text-3xl font-bold text-gray-900 dark:text-white text-center">
                Transformo Ideias em{' '}
                <span className="text-cobalt-600 dark:text-cobalt-400">Resultados</span>
              </h3>
              
              <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed text-center max-w-4xl mx-auto">
                Com mais de 5 anos de experiência em desenvolvimento web, especializo-me em criar landing pages 
                que combinam design impactante com estratégias de conversão comprovadas. Cada projeto é uma 
                oportunidade de elevar seus resultados de vendas.
              </p>
              
              <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed text-center max-w-4xl mx-auto">
                Minha abordagem vai além do código: analiso seu público-alvo, estudo a jornada do cliente e 
                implemento técnicas de psicologia da conversão para criar páginas que realmente vendem.
              </p>

              <div className="flex flex-wrap justify-center gap-4 pt-4">
                {['React', 'TypeScript', 'Tailwind CSS', 'Next.js', 'Analytics', 'A/B Testing'].map((tech) => (
                  <span
                    key={tech}
                    className="px-4 py-2 bg-cobalt-100 dark:bg-cobalt-900/30 text-cobalt-700 dark:text-cobalt-300 rounded-full text-sm font-medium"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Skills Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {skills.map((skill, index) => (
              <div
                key={index}
                className="group p-6 bg-gray-50 dark:bg-dark-800/50 rounded-2xl hover:bg-white dark:hover:bg-dark-800 transition-all duration-300 hover:shadow-lg hover:shadow-cobalt-500/10 border border-transparent hover:border-cobalt-200 dark:hover:border-cobalt-800"
              >
                <div className="text-cobalt-600 dark:text-cobalt-400 mb-4 group-hover:scale-110 transition-transform duration-300">
                  {skill.icon}
                </div>
                <h4 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                  {skill.title}
                </h4>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                  {skill.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
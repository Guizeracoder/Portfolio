import React, { useState } from 'react';
import { ExternalLink, Eye, Code, TrendingUp } from 'lucide-react';

const Portfolio: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<number | null>(null);

  const projects = [
    {
      id: 1,
      title: 'EcoFit - Suplementos Naturais',
      category: 'E-commerce',
      image: 'https://images.pexels.com/photos/4720267/pexels-photo-4720267.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Landing page para marca de suplementos com foco em conversão através de prova social e urgência.',
      results: {
        conversion: '+180%',
        leads: '2.500+',
        revenue: 'R$ 450K'
      },
      technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Analytics'],
      link: '#',
      features: [
        'Design responsivo otimizado para mobile',
        'Sistema de A/B testing integrado',
        'Checkout em uma única página',
        'Integração com WhatsApp Business'
      ]
    },
    {
      id: 2,
      title: 'MindCoach - Cursos Online',
      category: 'Educação',
      image: 'https://images.pexels.com/photos/7688336/pexels-photo-7688336.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Plataforma de vendas para cursos de desenvolvimento pessoal com estratégia de funil de vendas.',
      results: {
        conversion: '+220%',
        leads: '1.800+',
        revenue: 'R$ 320K'
      },
      technologies: ['Next.js', 'Stripe', 'Framer Motion', 'CRM Integration'],
      link: '#',
      features: [
        'Vídeo sales letter otimizada',
        'Contador de urgência dinâmico',
        'Sistema de cupons automático',
        'Integração com Hotmart'
      ]
    },
    {
      id: 3,
      title: 'TechStartup - SaaS Platform',
      category: 'SaaS',
      image: 'https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Landing page para startup de tecnologia com foco em captação de leads B2B qualificados.',
      results: {
        conversion: '+150%',
        leads: '950+',
        revenue: 'R$ 180K'
      },
      technologies: ['React', 'Node.js', 'PostgreSQL', 'AWS'],
      link: '#',
      features: [
        'Formulário inteligente multi-etapas',
        'Demo interativa do produto',
        'Case studies detalhados',
        'Integração com Salesforce'
      ]
    },
    {
      id: 4,
      title: 'BeautyPro - Clínica Estética',
      category: 'Saúde & Beleza',
      image: 'https://images.pexels.com/photos/3985357/pexels-photo-3985357.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Landing page para clínica de estética com agendamento online e conversão local.',
      results: {
        conversion: '+300%',
        leads: '3.200+',
        revenue: 'R$ 280K'
      },
      technologies: ['Vue.js', 'Calendar API', 'Google Maps', 'WhatsApp API'],
      link: '#',
      features: [
        'Agendamento online integrado',
        'Galeria de antes e depois',
        'Avaliações e depoimentos',
        'Localização e contato direto'
      ]
    },
    {
      id: 5,
      title: 'FinanceFlow - Consultoria',
      category: 'Finanças',
      image: 'https://images.pexels.com/photos/6120125/pexels-photo-6120125.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Página de captura para consultoria financeira com estratégia de alta conversão.',
      results: {
        conversion: '+250%',
        leads: '1.400+',
        revenue: 'R$ 520K'
      },
      technologies: ['React', 'Charts.js', 'Email Marketing', 'CRM'],
      link: '#',
      features: [
        'Calculadora financeira interativa',
        'Webinar ao vivo integrado',
        'Sequência de e-mails automática',
        'Dashboard de resultados'
      ]
    },
    {
      id: 6,
      title: 'FoodDelivery - App Launch',
      category: 'Mobile App',
      image: 'https://images.pexels.com/photos/4393426/pexels-photo-4393426.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Landing page para lançamento de app de delivery com pré-cadastro e gamificação.',
      results: {
        conversion: '+190%',
        leads: '5.500+',
        revenue: 'R$ 95K'
      },
      technologies: ['React Native', 'Firebase', 'Push Notifications', 'Analytics'],
      link: '#',
      features: [
        'Pré-cadastro com recompensas',
        'Mapa de cobertura interativo',
        'Sistema de referência',
        'Notificações push personalizadas'
      ]
    }
  ];

  const categories = ['Todos', 'E-commerce', 'Educação', 'SaaS', 'Saúde & Beleza', 'Finanças', 'Mobile App'];
  const [activeCategory, setActiveCategory] = useState('Todos');

  const filteredProjects = activeCategory === 'Todos' 
    ? projects 
    : projects.filter(project => project.category === activeCategory);

  return (
    <section id="portfolio" className="py-20 lg:py-32 bg-gray-50 dark:bg-dark-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              Portfólio de Projetos
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Cada projeto é uma história de sucesso. Veja como transformei ideias em 
              landing pages que geram resultados extraordinários.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                  activeCategory === category
                    ? 'bg-cobalt-600 text-white shadow-lg'
                    : 'bg-white dark:bg-dark-700 text-gray-600 dark:text-gray-300 hover:bg-cobalt-50 dark:hover:bg-dark-600'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Projects Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {filteredProjects.map((project) => (
              <div
                key={project.id}
                className="group bg-white dark:bg-dark-900 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2"
              >
                {/* Project Image */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  {/* Hover Actions */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <button
                      onClick={() => setSelectedProject(project.id)}
                      className="bg-white/90 hover:bg-white text-gray-900 p-3 rounded-full mr-3 transition-all duration-300 hover:scale-110"
                    >
                      <Eye className="w-5 h-5" />
                    </button>
                    <a
                      href={project.link}
                      className="bg-cobalt-600 hover:bg-cobalt-700 text-white p-3 rounded-full transition-all duration-300 hover:scale-110"
                    >
                      <ExternalLink className="w-5 h-5" />
                    </a>
                  </div>
                </div>

                {/* Project Info */}
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-cobalt-600 dark:text-cobalt-400 bg-cobalt-100 dark:bg-cobalt-900/30 px-3 py-1 rounded-full">
                      {project.category}
                    </span>
                  </div>
                  
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2 group-hover:text-cobalt-600 dark:group-hover:text-cobalt-400 transition-colors duration-300">
                    {project.title}
                  </h3>
                  
                  <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-2">
                    {project.description}
                  </p>

                  {/* Results */}
                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="text-center">
                      <div className="text-lg font-bold text-green-600">{project.results.conversion}</div>
                      <div className="text-xs text-gray-500">Conversão</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-blue-600">{project.results.leads}</div>
                      <div className="text-xs text-gray-500">Leads</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-purple-600">{project.results.revenue}</div>
                      <div className="text-xs text-gray-500">Receita</div>
                    </div>
                  </div>

                  {/* Technologies */}
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.slice(0, 3).map((tech) => (
                      <span
                        key={tech}
                        className="text-xs px-2 py-1 bg-gray-100 dark:bg-dark-700 text-gray-600 dark:text-gray-300 rounded"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Project Modal */}
          {selectedProject && (
            <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white dark:bg-dark-900 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                {(() => {
                  const project = projects.find(p => p.id === selectedProject);
                  if (!project) return null;
                  
                  return (
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-6">
                        <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                          {project.title}
                        </h3>
                        <button
                          onClick={() => setSelectedProject(null)}
                          className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                        >
                          ✕
                        </button>
                      </div>
                      
                      <img
                        src={project.image}
                        alt={project.title}
                        className="w-full h-64 object-cover rounded-xl mb-6"
                      />
                      
                      <p className="text-gray-600 dark:text-gray-300 mb-6">
                        {project.description}
                      </p>
                      
                      <div className="grid md:grid-cols-2 gap-8">
                        <div>
                          <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Resultados Alcançados</h4>
                          <div className="space-y-3">
                            <div className="flex items-center">
                              <TrendingUp className="w-5 h-5 text-green-600 mr-3" />
                              <span className="text-gray-600 dark:text-gray-300">Conversão: {project.results.conversion}</span>
                            </div>
                            <div className="flex items-center">
                              <Eye className="w-5 h-5 text-blue-600 mr-3" />
                              <span className="text-gray-600 dark:text-gray-300">Leads Gerados: {project.results.leads}</span>
                            </div>
                            <div className="flex items-center">
                              <TrendingUp className="w-5 h-5 text-purple-600 mr-3" />
                              <span className="text-gray-600 dark:text-gray-300">Receita: {project.results.revenue}</span>
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Principais Features</h4>
                          <ul className="space-y-2">
                            {project.features.map((feature, index) => (
                              <li key={index} className="flex items-start">
                                <div className="w-2 h-2 bg-cobalt-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                                <span className="text-gray-600 dark:text-gray-300">{feature}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                      
                      <div className="mt-8">
                        <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Tecnologias Utilizadas</h4>
                        <div className="flex flex-wrap gap-3">
                          {project.technologies.map((tech) => (
                            <span
                              key={tech}
                              className="px-4 py-2 bg-cobalt-100 dark:bg-cobalt-900/30 text-cobalt-700 dark:text-cobalt-300 rounded-full text-sm font-medium"
                            >
                              {tech}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
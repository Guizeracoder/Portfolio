import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials: React.FC = () => {
  const testimonials = [
    {
      id: 1,
      name: 'Carlos Silva',
      role: 'CEO, EcoFit Suplementos',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150',
      content: 'O Guilherme transformou completamente nossos resultados online. Nossa taxa de conversão aumentou 180% em apenas 3 meses. O profissionalismo e atenção aos detalhes são excepcionais.',
      rating: 5,
      results: 'Conversão +180%'
    },
    {
      id: 2,
      name: 'Marina Costa',
      role: 'Fundadora, MindCoach',
      image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150',
      content: 'Impressionante! A landing page criada pelo Guilherme gerou mais de R$ 320K em vendas. Ele entende de conversão como ninguém e entrega resultados que superam expectativas.',
      rating: 5,
      results: 'R$ 320K em vendas'
    },
    {
      id: 3,
      name: 'Roberto Fernandes',
      role: 'CTO, TechStartup',
      image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150',
      content: 'Trabalho impecável! A landing page B2B que o Guilherme desenvolveu nos ajudou a captar leads qualificados e fechar contratos importantes. Recomendo sem hesitar.',
      rating: 5,
      results: '950+ leads B2B'
    },
    {
      id: 4,
      name: 'Dra. Patricia Lima',
      role: 'Proprietária, BeautyPro Clínica',
      image: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
      content: 'A estratégia do Guilherme aumentou nossos agendamentos em 300%. A página é linda, funcional e converte muito bem. Parceria que transformou nosso negócio.',
      rating: 5,
      results: 'Agendamentos +300%'
    },
    {
      id: 5,
      name: 'André Oliveira',
      role: 'Consultor, FinanceFlow',
      image: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150',
      content: 'Guilherme criou uma landing page que gerou R$ 520K em consultoria. Seu conhecimento em CRO e psicologia da conversão fez toda a diferença nos resultados.',
      rating: 5,
      results: 'R$ 520K gerados'
    },
    {
      id: 6,
      name: 'Lucas Santos',
      role: 'Founder, FoodDelivery App',
      image: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=150',
      content: 'Conseguimos 5.500+ pré-cadastros para nosso app graças à estratégia do Guilherme. A gamificação na landing page foi genial e superou todas nossas expectativas.',
      rating: 5,
      results: '5.500+ pré-cadastros'
    }
  ];

  return (
    <section id="testimonials" className="py-20 lg:py-32 bg-gray-50 dark:bg-dark-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              O Que Dizem Meus Clientes
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Resultados reais de clientes que confiaram em meu trabalho para transformar 
              suas ideias em landing pages de alta conversão.
            </p>
          </div>

          {/* Testimonials Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <div
                key={testimonial.id}
                className="group bg-white dark:bg-dark-900 rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 relative overflow-hidden"
              >
                {/* Quote Icon */}
                <div className="absolute top-6 right-6 text-cobalt-200 dark:text-cobalt-800 opacity-20">
                  <Quote className="w-12 h-12" />
                </div>

                {/* Stars Rating */}
                <div className="flex items-center mb-6">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>

                {/* Testimonial Content */}
                <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed italic">
                  "{testimonial.content}"
                </p>

                {/* Results Badge */}
                <div className="inline-flex items-center px-4 py-2 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 rounded-full text-sm font-semibold mb-6">
                  {testimonial.results}
                </div>

                {/* Client Info */}
                <div className="flex items-center">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white">
                      {testimonial.name}
                    </h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {testimonial.role}
                    </p>
                  </div>
                </div>

                {/* Hover Effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-cobalt-500/0 to-blue-500/0 group-hover:from-cobalt-500/5 group-hover:to-blue-500/5 transition-all duration-500 pointer-events-none rounded-2xl"></div>
              </div>
            ))}
          </div>

          {/* Stats Section */}
          <div className="mt-20 grid grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-cobalt-600 dark:text-cobalt-400 mb-2">
                98%
              </div>
              <p className="text-gray-600 dark:text-gray-300">Taxa de Satisfação</p>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-cobalt-600 dark:text-cobalt-400 mb-2">
                50+
              </div>
              <p className="text-gray-600 dark:text-gray-300">Clientes Atendidos</p>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-cobalt-600 dark:text-cobalt-400 mb-2">
                2.5M+
              </div>
              <p className="text-gray-600 dark:text-gray-300">Receita Gerada</p>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-cobalt-600 dark:text-cobalt-400 mb-2">
                24h
              </div>
              <p className="text-gray-600 dark:text-gray-300">Tempo de Resposta</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
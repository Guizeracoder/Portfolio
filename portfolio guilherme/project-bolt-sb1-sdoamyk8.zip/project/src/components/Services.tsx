import React from 'react';
import { Rocket, Target, PenTool, Settings, BarChart3, Zap } from 'lucide-react';

const Services: React.FC = () => {
  const services = [
    {
      icon: <Rocket className="w-8 h-8" />,
      title: 'Desenvolvimento de Landing Pages',
      description: 'Criação de páginas otimizadas para conversão com design moderno e responsivo.',
      features: [
        'Design responsivo e mobile-first',
        'Otimização de velocidade de carregamento',
        'SEO técnico implementado',
        'Integração com analytics avançados'
      ],
      price: 'A partir de R$ 2.500',
      deliveryTime: '7-10 dias úteis'
    },
    {
      icon: <Target className="w-8 h-8" />,
      title: 'Otimização de Conversão (CRO)',
      description: 'Análise e otimização de páginas existentes para aumentar as taxas de conversão.',
      features: [
        'Auditoria completa de UX/UI',
        'Implementação de A/B testing',
        'Análise de heatmaps e sessões',
        'Relatórios detalhados de performance'
      ],
      price: 'A partir de R$ 1.800',
      deliveryTime: '5-7 dias úteis'
    },
    {
      icon: <PenTool className="w-8 h-8" />,
      title: 'Copy Estrutural',
      description: 'Desenvolvimento de copy persuasivo focado em conversão e resultados.',
      features: [
        'Análise do público-alvo',
        'Headlines impactantes',
        'CTAs otimizados para ação',
        'Storytelling estratégico'
      ],
      price: 'A partir de R$ 1.200',
      deliveryTime: '3-5 dias úteis'
    },
    {
      icon: <Settings className="w-8 h-8" />,
      title: 'Integração com Ferramentas',
      description: 'Conecte sua landing page com CRM, e-mail marketing e ferramentas de automação.',
      features: [
        'Integração com CRMs populares',
        'Automação de e-mail marketing',
        'Webhooks e APIs customizadas',
        'Pixel de rastreamento avançado'
      ],
      price: 'A partir de R$ 800',
      deliveryTime: '2-4 dias úteis'
    },
    {
      icon: <BarChart3 className="w-8 h-8" />,
      title: 'Analytics & Relatórios',
      description: 'Implementação de tracking avançado e relatórios de performance detalhados.',
      features: [
        'Google Analytics 4 configurado',
        'Conversão de eventos customizados',
        'Dashboards personalizados',
        'Relatórios mensais de performance'
      ],
      price: 'A partir de R$ 600',
      deliveryTime: '1-3 dias úteis'
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: 'Suporte & Manutenção',
      description: 'Suporte contínuo para manter sua landing page sempre otimizada e atualizada.',
      features: [
        'Suporte técnico prioritário',
        'Atualizações de segurança',
        'Backup automatizado',
        'Monitoramento de performance'
      ],
      price: 'A partir de R$ 400/mês',
      deliveryTime: 'Contínuo'
    }
  ];

  const whatsappMessage = encodeURIComponent('Olá! Quero fazer um site de alta conversão. Podemos conversar sobre meu projeto?');

  return (
    <section id="services" className="py-20 lg:py-32 bg-white dark:bg-dark-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              Serviços Especializados
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Soluções completas para transformar sua presença digital em uma máquina de vendas. 
              Cada serviço é pensado para maximizar suas conversões e resultados.
            </p>
          </div>

          {/* Services Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div
                key={index}
                className="group relative bg-gray-50 dark:bg-dark-800/50 rounded-2xl p-8 hover:bg-white dark:hover:bg-dark-800 transition-all duration-500 hover:shadow-xl hover:shadow-cobalt-500/10 border border-transparent hover:border-cobalt-200 dark:hover:border-cobalt-800"
              >
                {/* Service Icon */}
                <div className="text-cobalt-600 dark:text-cobalt-400 mb-6 group-hover:scale-110 transition-transform duration-300">
                  {service.icon}
                </div>

                {/* Service Title */}
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4 group-hover:text-cobalt-600 dark:group-hover:text-cobalt-400 transition-colors duration-300">
                  {service.title}
                </h3>

                {/* Service Description */}
                <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                  {service.description}
                </p>

                {/* Features List */}
                <ul className="space-y-3 mb-6">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <div className="w-2 h-2 bg-cobalt-600 dark:bg-cobalt-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                      <span className="text-sm text-gray-600 dark:text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* Pricing & Timeline */}
                <div className="pt-6 border-t border-gray-200 dark:border-dark-700">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-lg font-bold text-cobalt-600 dark:text-cobalt-400">
                      {service.price}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Entrega: {service.deliveryTime}
                  </p>
                </div>

                {/* Hover Effect */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-cobalt-500/0 to-blue-500/0 group-hover:from-cobalt-500/5 group-hover:to-blue-500/5 transition-all duration-500 pointer-events-none"></div>
              </div>
            ))}
          </div>

          {/* CTA Section */}
          <div className="text-center mt-16">
            <div className="bg-gradient-to-r from-cobalt-600 to-blue-600 rounded-2xl p-8 lg:p-12">
              <h3 className="text-2xl lg:text-3xl font-bold text-white mb-4">
                Pronto para Aumentar suas Conversões?
              </h3>
              <p className="text-cobalt-100 mb-8 max-w-2xl mx-auto">
                Vamos conversar sobre como posso ajudar a transformar sua ideia em uma landing page 
                que gera resultados reais. Consultoria inicial gratuita.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <a
                  href="#contact"
                  className="inline-flex items-center px-8 py-4 bg-white text-cobalt-600 font-semibold rounded-xl hover:bg-gray-100 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
                >
                  Solicitar Orçamento Gratuito
                </a>
                <a
                  href={`https://wa.me/5561996749932?text=${whatsappMessage}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center px-8 py-4 bg-transparent border-2 border-white text-white font-semibold rounded-xl hover:bg-white hover:text-cobalt-600 transition-all duration-300"
                >
                  Falar no WhatsApp
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
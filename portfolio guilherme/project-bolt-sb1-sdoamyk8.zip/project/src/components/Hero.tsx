import React from 'react';
import { ArrowRight, Download, MessageCircle } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden bg-gradient-to-br from-white via-gray-50 to-blue-50 dark:from-dark-900 dark:via-dark-800 dark:to-dark-900">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-r from-cobalt-600/10 to-transparent dark:from-cobalt-400/10"></div>
      <div className="absolute top-1/4 right-1/4 w-72 h-72 bg-cobalt-400/20 rounded-full blur-3xl animate-float"></div>
      <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-blue-300/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '-3s' }}></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-4xl mx-auto">
          {/* Badge */}
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-cobalt-100 dark:bg-cobalt-900/30 text-cobalt-700 dark:text-cobalt-300 text-sm font-medium mb-8 animate-fadeInUp">
            <span className="w-2 h-2 bg-cobalt-500 rounded-full mr-2 animate-pulse"></span>
            Disponível para novos projetos
          </div>

          {/* Main Heading */}
          <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold text-gray-900 dark:text-white mb-6 animate-fadeInUp" style={{ animationDelay: '0.2s' }}>
            Olá, eu sou{' '}
            <span className="bg-gradient-to-r from-cobalt-600 to-blue-500 bg-clip-text text-transparent">
              Guilherme
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl sm:text-2xl lg:text-3xl text-gray-600 dark:text-gray-300 mb-4 animate-fadeInUp" style={{ animationDelay: '0.4s' }}>
            Desenvolvedor Web &
          </p>
          <p className="text-lg sm:text-xl lg:text-2xl text-gray-500 dark:text-gray-400 mb-8 animate-fadeInUp" style={{ animationDelay: '0.6s' }}>
            Especialista em Landing Pages de{' '}
            <span className="text-cobalt-600 dark:text-cobalt-400 font-semibold">Alta Conversão</span>
          </p>

          {/* Description */}
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto mb-12 leading-relaxed animate-fadeInUp" style={{ animationDelay: '0.8s' }}>
            Transformo ideias em páginas que vendem. Especializado em criar experiências digitais que geram resultados mensuráveis e aumentam suas conversões.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fadeInUp" style={{ animationDelay: '1s' }}>
            <a
              href="#portfolio"
              className="group inline-flex items-center px-8 py-4 bg-cobalt-600 hover:bg-cobalt-700 text-white font-semibold rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl hover:shadow-cobalt-500/25 transform hover:-translate-y-1"
            >
              Ver Portfólio
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
            </a>
            
            <a
              href="#contact"
              className="group inline-flex items-center px-8 py-4 bg-transparent border-2 border-cobalt-600 text-cobalt-600 dark:text-cobalt-400 dark:border-cobalt-400 font-semibold rounded-xl hover:bg-cobalt-600 hover:text-white transition-all duration-300"
            >
              Solicitar Projeto
              <MessageCircle className="ml-2 w-5 h-5 group-hover:scale-110 transition-transform duration-300" />
            </a>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 mt-20 animate-fadeInUp" style={{ animationDelay: '1.2s' }}>
            <div className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-cobalt-600 dark:text-cobalt-400">100+</div>
              <div className="text-gray-600 dark:text-gray-400 mt-2">Projetos Concluídos</div>
            </div>
            <div className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-cobalt-600 dark:text-cobalt-400">50+</div>
              <div className="text-gray-600 dark:text-gray-400 mt-2">Clientes Satisfeitos</div>
            </div>
            <div className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-cobalt-600 dark:text-cobalt-400">3x</div>
              <div className="text-gray-600 dark:text-gray-400 mt-2">Aumento Médio de Conversão</div>
            </div>
            <div className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-cobalt-600 dark:text-cobalt-400">24h</div>
              <div className="text-gray-600 dark:text-gray-400 mt-2">Tempo de Resposta</div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-gray-400 dark:border-gray-600 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-gray-400 dark:bg-gray-600 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;